@extends('web.common.app')
@section('content')

    <div>

        <!-- Start Page Title Area -->
        <div class="page-title-area item-bg-2">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <div class="page-title-content">
                            <h2>Test & Package</h2>
                            <ul>
                                <li><a href="{{ url('/') }}">Home</a></li>
                                <li>Test</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Page Title Area -->

        <!-- Start Services Area -->
        <section class="services-area bg-ffffff pt-100 pb-70 test-page">
            <div class="container">
                <div class="row">
                    @forelse ($tests as $test)
                        <div class="col-lg-4 col-md-6">
                            <div class="single-services-item">
                                <a href="{{ url('/test-detail') }}/{{ encryptWithPasscode($test->id) }}">
                                    <div class="icon">
                                        @if (request()->getHost() == '127.0.0.1')
                                            @if ($test->icon)
                                                <img src="{{ url($test->icon) }}" />
                                            @endif
                                        @else
                                            @if ($test->icon)
                                                <img src="{{ url('public/' . $test->icon) }}" />
                                            @endif
                                        @endif

                                    </div>
                                </a>

                                <h3>
                                    <a href="{{ url('/test-detail') }}/{{ encryptWithPasscode($test->id) }}">
                                        {{-- {{ Str::words($test->test_name, 3, '...') }} --}}
                                        {{ $test->test_name }}
                                    </a>
                                </h3>
                                <p>{{ Str::words($test->short_desc, 18, '...') }}</p>
                                <a href="{{ url('/book-appointment') }}/{{ encryptWithPasscode($test->id) }}"
                                    class="read-more-btn">Book Now</a>
                            </div>

                        </div>
                    @empty
                        <div class="col-md-12">
                            <div class="top-services-item">
                                <p>No Data found</p>
                            </div>
                        </div>
                    @endforelse

                </div>
            </div>
        </section>

        <section class="services-area bg-white pb-70 pt-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-md-6">
                        <div class="single-services-item">
                            <div class="icon">
                                <img src="{{ asset('assets/img/On-timeSampleCollection.png') }}" alt="" />
                            </div>
                            <h3>
                                <a href="#">On-Time Free Home Simple Collection
                                </a>
                            </h3>
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6">
                        <div class="single-services-item">
                            <div class="icon">

                                <img src="{{ asset('assets/img/DOCTORCONSULTATION.jpg') }}" alt="" />
                            </div>
                            <h3>
                                <a href="#">DOCTOR CONSULTATION</a>
                            </h3>

                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6">
                        <div class="single-services-item">
                            <div class="icon">

                                <img src="{{ asset('assets/img/NABL.png') }}" alt="" />
                            </div>
                            <h3>
                                <a href="#">NABL Certified Labs</a>
                            </h3>

                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6">
                        <div class="single-services-item">
                            <div class="icon">
                                <img src="{{ asset('assets/img/6179923.png') }}" alt="" />
                            </div>
                            <h3>
                                <a href="#">24/7 Service
                                </a>
                            </h3>

                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6">
                        <div class="single-services-item">
                            <div class="icon">
                                <img src="{{ asset('assets/img/GUARANTEEDACCURACY.jpg') }}" alt="" />
                            </div>
                            <h3>
                                <a href="#">GUARANTEED ACCURACY
                                </a>
                            </h3>
                        </div>
                    </div>



                    <div class="col-lg-2 col-md-6">
                        <div class="single-services-item">
                            <div class="icon">

                                <img src="{{ asset('assets/img/HONESTPRICES.png') }}" alt="" />
                            </div>
                            <h3>
                                <a href="#">HONEST PRICES</a>
                            </h3>

                        </div>
                    </div>

                </div>
            </div>
        </section>

        <!-- Start Newsletter Area -->
        <div class="newsletter-area pb-100 pt-100">
            <div class="container">
                <div class="newsletter-inner">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="newsletter-content">
                                <h2>Subscribe To Our Newsletter</h2>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <form class="newsletter-form">
                                <input type="email" class="input-newsletter" placeholder="Your Email" name="EMAIL"
                                    required autocomplete="off">

                                <button type="submit">
                                    Subscribe Now
                                </button>

                                <div id="validator-newsletter" class="form-result"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Newsletter Area -->

    </div>



@endsection
