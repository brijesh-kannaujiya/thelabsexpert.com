@extends('web.common.app')

@section('content')
    <div>

        <!-- Start Page Title Area -->
        <div class="page-title-area item-bg-1">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <div class="page-title-content">
                            <h2>Services</h2>
                            <ul>
                                <li><a href="{{ url('/') }}">Home</a></li>
                                <li>Services</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Page Title Area -->

        <!-- Start Services Area -->
        <section class="services-area bg-ffffff pt-100 pb-70">
            <div class="container">
                <div class="section-title">
                    <span>Services</span>
                    <h2>Our Core Services</h2>
                </div>

                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="single-services-item">
                            <div class="icon">
                                <i class="flaticon-microscope"></i>
                            </div>
                            <h3>
                                <a href="#">Advanced Microscopy</a>
                            </h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor</p>
                            <a href="{{ url('/services-details') }}" class="read-more-btn">Read More +</a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="single-services-item">
                            <div class="icon">
                                <i class="flaticon-laboratory"></i>
                            </div>
                            <h3>
                                <a href="{{ url('/services-details') }}">Molecular Biology</a>
                            </h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor</p>
                            <a href="{{ url('/services-details') }}" class="read-more-btn">Read More +</a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="single-services-item">
                            <div class="icon">
                                <i class="flaticon-sugar-blood-level"></i>
                            </div>
                            <h3>
                                <a href="{{ url('/services-details') }}">Diabetes Testing</a>
                            </h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor</p>
                            <a href="{{ url('/services-details') }}" class="read-more-btn">Read More +</a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="single-services-item">
                            <div class="icon">
                                <i class="flaticon-lab-tool"></i>
                            </div>
                            <h3>
                                <a href="{{ url('/services-details') }}">Chemical Research</a>
                            </h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor</p>
                            <a href="{{ url('/services-details') }}" class="read-more-btn">Read More +</a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="single-services-item">
                            <div class="icon">
                                <i class="flaticon-lungs"></i>
                            </div>
                            <h3>
                                <a href="{{ url('/services-details') }}">Anatomical Pathology</a>
                            </h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor</p>
                            <a href="{{ url('/services-details') }}" class="read-more-btn">Read More +</a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="single-services-item">
                            <div class="icon">
                                <i class="flaticon-heart"></i>
                            </div>
                            <h3>
                                <a href="{{ url('/services-details') }}">Heart Disease</a>
                            </h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor</p>
                            <a href="{{ url('/services-details') }}" class="read-more-btn">Read More +</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Services Area -->

        <!-- Start How It Works Area -->
        <section class="how-it-works-area ptb-100">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-5">
                        <div class="how-it-works-content">
                            <span>How It Works</span>
                            <h3>Receive Your Test 3 Easy Way Steps</h3>
                            <strong>Your full-service lab for clinical trials. Our mission is to ensure the generation of
                                accurate and precise findings</strong>

                            <div class="how-it-works-text">
                                <div class="number">
                                    <span>1</span>
                                </div>
                                <h4>Get Started</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                                    dolore. magna aliqua.</p>
                            </div>

                            <div class="how-it-works-text">
                                <div class="number">
                                    <span>2</span>
                                </div>
                                <h4>Prepare your test</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                                    dolore. magna aliqua.</p>
                            </div>

                            <div class="how-it-works-text">
                                <div class="number">
                                    <span>3</span>
                                </div>
                                <h4>Get Test Result</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                                    dolore. magna aliqua.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-7">
                        <div class="how-it-works-image">
                            <img src="{{ asset('assets/img/how-it-works.png') }}" alt="image">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End How It Works Area -->

        <!-- Start Why Choose Area -->
        <section class="why-choose-area bg-ffffff ptb-100">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="why-choose-content">
                            <span>Why Choose Us</span>
                            <h3>Over 20 Years of Experience With Best Results</h3>
                            <strong>Your full-service lab for clinical trials. Our mission is to ensure the generation of
                                accurate and precise findings</strong>

                            <div class="why-choose-text">
                                <div class="icon">
                                    <i class="las la-check"></i>
                                </div>
                                <h4>Free Home Sampling</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                                    dolore. magna aliqua.</p>
                            </div>

                            <div class="why-choose-text">
                                <div class="icon">
                                    <i class="las la-check"></i>
                                </div>
                                <h4>High- End Technology</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                                    dolore. magna aliqua.</p>
                            </div>

                            <div class="why-choose-text">
                                <div class="icon">
                                    <i class="las la-check"></i>
                                </div>
                                <h4>Patient Support</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                                    dolore. magna aliqua.</p>
                            </div>

                            <div class="why-choose-text">
                                <div class="icon">
                                    <i class="las la-check"></i>
                                </div>
                                <h4>500 + Different Tests</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                                    dolore. magna aliqua.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="why-choose-image">
                            <img src="{{ asset('assets/img/why-choose.png') }}" alt="image">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Why Choose Area -->

        <!-- Start Testing Area -->
        <section class="testing-area pb-100">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="testing-image">
                            <img src="{{ asset('assets/img/testing.png') }}" alt="image">

                            <a href="https://www.youtube.com/watch?v=6NuAPBTOt0M" class="video-btn popup-youtube">
                                <i class="las la-play"></i>
                            </a>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="testing-inner">
                            <div class="testing-content">
                                <h3>Testing by Our Expert Lab Scientists</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                                    ut labore et dolore magna aliqua.</p>
                            </div>

                            <div class="skill-bar" data-percentage="78%">
                                <p class="progress-title-holder">
                                    <span class="progress-title">Sample professional</span>
                                    <span class="progress-number-wrapper">
                                        <span class="progress-number-mark">
                                            <span class="percent"></span>
                                            <span class="down-arrow"></span>
                                        </span>
                                    </span>
                                </p>
                                <div class="progress-content-outter">
                                    <div class="progress-content"></div>
                                </div>
                            </div>

                            <div class="skill-bar" data-percentage="58%">
                                <p class="progress-title-holder">
                                    <span class="progress-title">Environmental Testing</span>
                                    <span class="progress-number-wrapper">
                                        <span class="progress-number-mark">
                                            <span class="percent"></span>
                                            <span class="down-arrow"></span>
                                        </span>
                                    </span>
                                </p>
                                <div class="progress-content-outter">
                                    <div class="progress-content"></div>
                                </div>
                            </div>

                            <div class="skill-bar" data-percentage="88%">
                                <p class="progress-title-holder">
                                    <span class="progress-title">Advanced Microscopy</span>
                                    <span class="progress-number-wrapper">
                                        <span class="progress-number-mark">
                                            <span class="percent"></span>
                                            <span class="down-arrow"></span>
                                        </span>
                                    </span>
                                </p>
                                <div class="progress-content-outter">
                                    <div class="progress-content"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End TestingArea -->

        <!-- Start Newsletter Area -->
        <div class="newsletter-area ptb-100">
            <div class="container">
                <div class="newsletter-inner">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="newsletter-content">
                                <h2>Subscribe To Our Newsletter</h2>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <form class="newsletter-form">
                                <input type="email" class="input-newsletter" placeholder="Your Email" name="EMAIL"
                                    required autocomplete="off">

                                <button type="submit">
                                    Subscribe Now
                                </button>

                                <div id="validator-newsletter" class="form-result"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Newsletter Area -->

    </div>
@endsection
